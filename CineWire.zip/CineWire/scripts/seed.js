const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const env = require('../src/config/env');
const Admin = require('../src/models/Admin');
const User = require('../src/models/User');
const Article = require('../src/models/Article');
const DeviceToken = require('../src/models/DeviceToken');

const seedData = async () => {
  try {
    console.log('[Seed] Connecting to MongoDB...');
    await mongoose.connect(env.mongoUri);
    console.log('[Seed] Database connected.');

    // Clear existing collections
    await Admin.deleteMany({});
    await User.deleteMany({});
    await Article.deleteMany({});
    await DeviceToken.deleteMany({});

    console.log('[Seed] Collections cleared.');

    // 1. Create Default Admin
    const adminPasswordHash = await bcrypt.hash('AdminPass123!', 10);
    const admin = await Admin.create({
      email: 'admin@cinewire.com',
      passwordHash: adminPasswordHash,
      role: 'admin'
    });
    console.log(`[Seed] Admin created: ${admin.email}`);

    // 2. Create Sample Public User (Verified with pre-created OTP history)
    const userPasswordHash = await bcrypt.hash('UserPass123!', 10);
    const user = await User.create({
      email: 'user@cinewire.com',
      passwordHash: userPasswordHash,
      isVerified: true,
      bookmarks: []
    });
    console.log(`[Seed] Verified User created: ${user.email}`);

    // 3. Create Sample Articles across Countries, Categories, Published & Draft statuses
    const articlesData = [
      {
        title: 'Christopher Nolan Announces Next Sci-Fi Epic Project',
        slug: 'christopher-nolan-announces-next-sci-fi-epic-project',
        shortDescription: 'Acclaimed director Christopher Nolan unveils details for his upcoming IMAX sci-fi blockbuster.',
        body: 'Christopher Nolan is set to return to the big screen with an ambitious original sci-fi feature film. Details surrounding the plot remain tightly under wraps, but production sources confirm IMAX 70mm filming will begin early next year across multiple international locations.',
        category: 'Sci-Fi',
        country: 'USA',
        language: 'English',
        imageUrl: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba',
        sourceName: 'Hollywood Reporter',
        published: true,
        publishedAt: new Date(Date.now() - 3600000 * 2), // 2 hours ago
        isTrending: true,
        createdBy: admin._id
      },
      {
        title: 'SS Rajamouli Teases High-Octane Action Sequence for Globe-Trotting Drama',
        slug: 'ss-rajamouli-teases-high-octane-action-sequence-telugu',
        shortDescription: 'Indian cinema visionary SS Rajamouli promises groundbreaking VFX and record-breaking action stunts.',
        body: 'Following the unprecedented global triumph of RRR, director SS Rajamouli has shared insights into his upcoming globetrotting adventure film. Pre-production is currently underway in Hyderabad with custom camera rigs built specifically for complex stunt work.',
        category: 'Action',
        country: 'India',
        language: 'Telugu',
        imageUrl: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1',
        sourceName: 'Cinema Express',
        published: true,
        publishedAt: new Date(Date.now() - 3600000 * 5), // 5 hours ago
        isTrending: true,
        createdBy: admin._id
      },
      {
        title: 'New Horror Sensation Claims Top Spot at Global Box Office',
        slug: 'new-horror-sensation-claims-top-spot-at-global-box-office',
        shortDescription: 'Supernatural thriller defies box office expectations with a record $45M opening weekend.',
        body: 'Audiences around the world flocked to theaters this weekend as the indie supernatural horror flick captured the number one spot at the worldwide box office. Critics have lauded its atmospheric tension and nerve-wracking practical effects.',
        category: 'Horror',
        country: 'USA',
        language: 'English',
        imageUrl: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5',
        sourceName: 'Variety',
        published: true,
        publishedAt: new Date(Date.now() - 3600000 * 12),
        isTrending: true,
        createdBy: admin._id
      },
      {
        title: 'Bollywood Romance Musical Breaks Streaming Records in India',
        slug: 'bollywood-romance-musical-breaks-streaming-records-hindi',
        shortDescription: 'Heartwarming musical romance reaches 50 million streams within first 48 hours.',
        body: 'The latest Hindi romantic comedy musical featuring stellar choreography and chart-topping soundtracks has achieved unprecedented streaming milestones across Asia and international markets.',
        category: 'Romance',
        country: 'India',
        language: 'Hindi',
        imageUrl: 'https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c',
        sourceName: 'Bollywood Hungama',
        published: true,
        publishedAt: new Date(Date.now() - 3600000 * 24),
        isTrending: false,
        createdBy: admin._id
      },
      {
        title: '[UNPUBLISHED DRAFT] Confidential Casting Leak for Major Franchise Reboot',
        slug: 'confidential-casting-leak-for-major-franchise-reboot-draft',
        shortDescription: 'Internal draft details regarding unannounced actor auditions for upcoming fantasy thriller reboot.',
        body: 'THIS IS A DRAFT ARTICLE. DO NOT PUBLISH TO PUBLIC FEEDS. Leaked audition logs indicate top A-list talents are testing for the lead role in the upcoming dark fantasy remake.',
        category: 'Fantasy',
        country: 'UK',
        language: 'English',
        imageUrl: 'https://images.unsplash.com/photo-1478720568477-152d9b164e26',
        sourceName: 'Internal Leak',
        published: false, // DRAFT - Must NEVER be returned by public queries
        publishedAt: null,
        isTrending: false,
        createdBy: admin._id
      }
    ];

    const insertedArticles = await Article.insertMany(articlesData);
    console.log(`[Seed] ${insertedArticles.length} Articles seeded (${insertedArticles.filter(a => a.published).length} published, ${insertedArticles.filter(a => !a.published).length} draft).`);

    // 4. Seed sample Device Token
    await DeviceToken.create({
      token: 'fcm_sample_device_token_9988776654321',
      country: 'USA'
    });
    console.log('[Seed] Sample FCM device token seeded.');

    console.log('\n====================================================');
    console.log('  🎉 Database Seeding Completed Successfully!');
    console.log('====================================================');
    console.log('  Admin Credentials:   admin@cinewire.com / AdminPass123!');
    console.log('  User Credentials:    user@cinewire.com  / UserPass123!');
    console.log('====================================================\n');

    process.exit(0);
  } catch (error) {
    console.error(`[Seed Error] ${error.message}`);
    process.exit(1);
  }
};

seedData();
