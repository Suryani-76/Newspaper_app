# 🎬 CineWire Backend Service

**CineWire** is a high-performance, stateless, horizontally scalable Node.js + Express backend service for a global film-industry news aggregator. 

Browsing and reading film news is **100% open with no login gate**. Public user accounts are optional and exclusively unlock bookmark synchronization. Admin CMS users manage content publishing and AI-assisted metadata generation.

---

## 🛠️ Tech Stack & Architecture

- **Runtime & Framework:** Node.js + Express (Stateless, single deployable service)
- **Database:** MongoDB (Mongoose ODM)
  - Articles indexed on `country`, `published`, `category`, `isTrending`
  - Full-text search index on `title`, `shortDescription`, `body`
  - Users collection with OTP activation & `bookmarks` array
  - Admin collection with role hierarchy (`admin`, `marketer`)
  - DeviceToken collection for FCM push tokens
- **Caching Layer:** Redis (`ioredis`)
  - Feed caching for country feeds, trending, latest, and category endpoints
  - Instant cache invalidation on `POST /api/article/:id/publish`
  - Graceful bypass fallback if Redis is unavailable
- **Authentication:** Dual-Tier JWT
  - `requireAuth` for public users accessing bookmark endpoints
  - `requireAdmin` with role checks for CMS management routes
- **Push Notifications:** Firebase FCM device-token subscription
- **AI Integration:** Pay-per-use API service client for article summarisation, auto-tagging, translation, and duplicate detection
- **Security:** Helmet, CORS, input validation via `express-validator`, bcrypt password hashing, and `express-rate-limit`

---

## 🚀 Getting Started

### 1. Prerequisites
- Node.js (v18+)
- MongoDB running locally or accessible via URL
- Redis server (optional; app gracefully falls back to direct DB queries if Redis is offline)

### 2. Environment Setup
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```

Key environment variables:
```env
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/cinewire
REDIS_URI=redis://127.0.0.1:6379
JWT_SECRET=cinewire_public_user_jwt_secret_key_2026
JWT_ADMIN_SECRET=cinewire_admin_cms_jwt_secret_key_2026
AI_API_KEY=cw_ai_pay_per_use_key_9988776655
```

### 3. Installation
Install project dependencies:
```bash
npm install
```

### 4. Database Seeding
Seed initial Admin, User, and sample published/draft articles across categories and countries:
```bash
npm run seed
```

Default credentials created by seed script:
- **Admin CMS:** `admin@cinewire.com` / `AdminPass123!`
- **Verified Public User:** `user@cinewire.com` / `UserPass123!`

### 5. Running the Service
Development mode (auto-reload):
```bash
npm run dev
```

Production start:
```bash
npm start
```

### 6. Running Integration Tests
Execute the comprehensive test suite verifying unauthenticated reading, draft protection, auth, bookmarks, admin CRUD, and push endpoints:
```bash
npm test
```

---

## 📡 Complete API Endpoint Reference

### Public — Read (No Auth Required)
> **Note:** All public read queries enforce `published: true` server-side. Draft/unpublished articles are NEVER returned.

| Method | Endpoint | Cache | Description |
|---|---|---|---|
| `GET` | `/api/feed/:country` | Redis (5m) | Returns published news feed for specified country (e.g. `USA`, `India`, `UK`) |
| `GET` | `/api/news/trending` | Redis (5m) | Returns trending published film articles |
| `GET` | `/api/news/latest` | Redis (3m) | Returns latest published articles across all regions |
| `GET` | `/api/news/category/:category` | Redis (5m) | Returns published articles by category (`Horror`, `Sci-Fi`, `Action`, `Drama`, etc.) |
| `GET` | `/api/news/search?q={query}` | No | Performs full-text search on article `title`, `shortDescription`, and `body` |
| `GET` | `/api/article/:id` | No | Returns detailed view of a single published article (returns 404 for drafts) |

### Public — Auth & Bookmarks (Optional Account, JWT Required for Bookmarks)

| Method | Endpoint | Auth | Description |
|---|---|---|---|
| `POST` | `/api/auth/register` | None | Register unverified user account; generates 6-digit OTP |
| `POST` | `/api/auth/verify-otp` | None | Verify account with 6-digit OTP code to enable bookmarking |
| `POST` | `/api/auth/login` | None | Authenticate public user and receive User JWT |
| `POST` | `/api/bookmarks/:id` | User JWT | Add published article to user's saved bookmarks |
| `DELETE` | `/api/bookmarks/:id` | User JWT | Remove article from user's saved bookmarks |
| `GET` | `/api/bookmarks` | User JWT | Retrieve array of user's bookmarked articles |

### Admin CMS (JWT & Role Verification Required)

| Method | Endpoint | Auth | Description |
|---|---|---|---|
| `POST` | `/api/admin/auth/login` | None | Authenticate CMS admin/marketer; returns Admin JWT |
| `POST` | `/api/article` | Admin JWT | Create a new article (draft or published) |
| `PUT` | `/api/article/:id` | Admin JWT | Update an existing article's metadata/content |
| `POST` | `/api/article/:id/publish` | Admin JWT | Toggle article `published` status & invalidate Redis feed caches |
| `POST` | `/api/ai/assist` | Admin JWT | Execute AI assistance (`summarise`, `tag`, `translate`, `duplicateCheck`) |

### Push Notifications (No Auth Required)

| Method | Endpoint | Auth | Description |
|---|---|---|---|
| `POST` | `/api/push/subscribe` | None | Register/upsert FCM device token and country preference |

---

## 🔒 Security & Performance Features

1. **Published Enforcer**: Every public database query includes `{ published: true }` hardcoded in the controller logic. Query params cannot override this filter.
2. **Dual-JWT Auth**: Public user JWT tokens use `JWT_SECRET`; Admin CMS JWT tokens use `JWT_ADMIN_SECRET` and enforce role checks (`admin`, `marketer`).
3. **Cache Invalidation**: Publishing or updating an article automatically invalidates cached country feeds, trending, and category lists.
4. **App Rate Limiting**: General endpoints limited to 60 req/min (fallback behind Cloudflare edge WAF). Sensitive auth endpoints limited to 10 req/15min.
