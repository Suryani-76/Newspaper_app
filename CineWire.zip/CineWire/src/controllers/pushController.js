const pushService = require('../services/pushService');

/**
 * Push Notification Controller
 * Public endpoint (no user account required)
 */

// POST /api/push/subscribe - Register device token + country
const subscribe = async (req, res, next) => {
  try {
    const { token, country } = req.body;

    if (!token || !country) {
      return res.status(400).json({
        success: false,
        error: 'Both "token" and "country" parameters are required.'
      });
    }

    const deviceToken = await pushService.registerToken({
      token,
      country
    });

    return res.status(200).json({
      success: true,
      message: 'Device push notification token registered successfully.',
      data: {
        token: deviceToken.token,
        country: deviceToken.country,
        subscribedAt: deviceToken.createdAt
      }
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  subscribe
};
