const Article = require('../models/Article');
const aiService = require('../services/aiService');
const { clearFeedCaches } = require('../services/redisService');

/**
 * Admin CMS Controller
 * All routes require requireAdmin middleware
 */

// Helper to generate a URL-friendly slug
const generateSlug = (title) => {
  return title
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, '')
    .replace(/[\s_-]+/g, '-')
    .replace(/^-+|-+$/g, '') + '-' + Date.now();
};

// POST /api/article - Create article
const createArticle = async (req, res, next) => {
  try {
    const {
      title,
      shortDescription,
      body,
      category,
      country,
      language,
      imageUrl,
      sourceName,
      published,
      isTrending
    } = req.body;

    const slug = req.body.slug ? req.body.slug.toLowerCase().trim() : generateSlug(title);

    const isPublished = published === true || published === 'true';
    const publishedAt = isPublished ? new Date() : null;

    const article = await Article.create({
      title,
      slug,
      shortDescription,
      body,
      category,
      country,
      language: language || 'English',
      imageUrl: imageUrl || '',
      sourceName: sourceName || 'CineWire Desk',
      published: isPublished,
      publishedAt,
      isTrending: isTrending === true || isTrending === 'true',
      createdBy: req.admin ? req.admin._id : (req.user ? (req.user.id || req.user._id) : null)
    });

    if (isPublished) {
      await clearFeedCaches(country, category);
    }

    return res.status(201).json({
      success: true,
      message: 'Article created successfully.',
      data: article
    });
  } catch (error) {
    next(error);
  }
};

// PUT /api/article/:id - Update article
const updateArticle = async (req, res, next) => {
  try {
    const { id } = req.params;

    let article = await Article.findById(id);
    if (!article) {
      return res.status(404).json({
        success: false,
        error: 'Article not found.'
      });
    }

    const updates = { ...req.body };
    delete updates.createdBy; // Prevent transferring ownership

    if (updates.title && !updates.slug) {
      updates.slug = generateSlug(updates.title);
    }

    if (updates.published !== undefined) {
      const isPublished = updates.published === true || updates.published === 'true';
      updates.published = isPublished;
      if (isPublished && !article.publishedAt) {
        updates.publishedAt = new Date();
      }
    }

    const updatedArticle = await Article.findByIdAndUpdate(id, updates, {
      new: true,
      runValidators: true
    });

    // Invalidate Redis cache whenever content or status changes
    await clearFeedCaches(updatedArticle.country, updatedArticle.category);

    return res.status(200).json({
      success: true,
      message: 'Article updated successfully.',
      data: updatedArticle
    });
  } catch (error) {
    next(error);
  }
};

// POST /api/article/:id/publish - Publish/Unpublish toggle
const togglePublish = async (req, res, next) => {
  try {
    const { id } = req.params;

    const article = await Article.findById(id);
    if (!article) {
      return res.status(404).json({
        success: false,
        error: 'Article not found.'
      });
    }

    // Toggle publish status
    article.published = !article.published;
    if (article.published && !article.publishedAt) {
      article.publishedAt = new Date();
    }
    await article.save();

    // Immediately invalidate relevant Redis cache keys
    await clearFeedCaches(article.country, article.category);

    return res.status(200).json({
      success: true,
      message: `Article successfully ${article.published ? 'published' : 'unpublished'}.`,
      published: article.published,
      publishedAt: article.publishedAt,
      data: article
    });
  } catch (error) {
    next(error);
  }
};

// POST /api/ai/assist - Trigger AI assist (summarise, tag, translate, duplicate-check)
const aiAssist = async (req, res, next) => {
  try {
    const { action, text, targetLanguage } = req.body;

    if (!action || !text) {
      return res.status(400).json({
        success: false,
        error: 'Parameters "action" and "text" are required.'
      });
    }

    let existingTitles = [];
    if (action === 'duplicateCheck' || action === 'duplicate-check') {
      const recentArticles = await Article.find().select('title').limit(100);
      existingTitles = recentArticles.map(a => a.title);
    }

    const result = await aiService.assist({
      action,
      text,
      targetLanguage,
      existingTitles
    });

    return res.status(200).json({
      success: true,
      data: result
    });
  } catch (error) {
    return res.status(400).json({
      success: false,
      error: error.message
    });
  }
};

module.exports = {
  createArticle,
  updateArticle,
  togglePublish,
  aiAssist
};
