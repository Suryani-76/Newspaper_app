const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const env = require('../config/env');
const User = require('../models/User');
const Admin = require('../models/Admin');

/**
 * Generate JWT payload for user
 * Includes id, email, and role markers
 */
const generateUserToken = (user) => {
  return jwt.sign(
    { id: user._id, email: user.email, role: user.role },
    env.jwtSecret,
    { expiresIn: env.jwtExpiresIn }
  );
};

/**
 * Generate JWT payload for admin
 * Includes id, email, and role markers
 */
const generateAdminToken = (admin) => {
  return jwt.sign(
    { id: admin._id, email: admin.email, role: admin.role },
    env.jwtSecret,
    { expiresIn: env.jwtExpiresIn }
  );
};

/**
 * POST /api/auth/login - Login dispatch handler
 * Securely verifies credentials, signs JWT with role marker, returns token
 */
const login = async (req, res, next) => {
  try {
    const { email, password, isAdmin } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        error: 'Email and password are required.'
      });
    }

    // If request explicitly sets isAdmin or calls admin login, delegate to admin authentication
    if (isAdmin) {
      return adminLogin(req, res, next);
    }

    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) {
      return res.status(401).json({
        success: false,
        error: 'Invalid credentials.'
      });
    }

    const isMatch = await bcrypt.compare(password, user.passwordHash);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        error: 'Invalid credentials.'
      });
    }

    const token = generateUserToken(user);

    return res.status(200).json({
      success: true,
      token,
      data: {
        id: user._id,
        email: user.email,
        role: user.role,
        isVerified: user.isVerified
      }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * POST /api/admin/auth/login - Admin CMS Login
 * Verifies admin credentials, signs JWT with role marker, returns token
 */
const adminLogin = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        error: 'Admin email and password are required.'
      });
    }

    const admin = await Admin.findOne({ email: email.toLowerCase() });
    if (!admin) {
      return res.status(401).json({
        success: false,
        error: 'Invalid admin credentials.'
      });
    }

    const isMatch = await bcrypt.compare(password, admin.passwordHash);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        error: 'Invalid admin credentials.'
      });
    }

    const token = generateAdminToken(admin);

    return res.status(200).json({
      success: true,
      token,
      data: {
        id: admin._id,
        email: admin.email,
        role: admin.role
      }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * POST /api/auth/protected - Isolated protected handler
 * Demonstrates stacking authenticateToken and requireRole('admin')
 * to guard access to administrative backend operations
 */
const protectedHandler = async (req, res) => {
  return res.status(200).json({
    success: true,
    message: 'Access granted to protected resource.',
    data: {
      userId: req.user.id,
      email: req.user.email,
      role: req.user.role
    }
  });
};

/**
 * POST /api/auth/register - Public User Registration
 */
const register = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        error: 'Email and password are required.'
      });
    }

    const existingUser = await User.findOne({ email: email.toLowerCase() });
    if (existingUser) {
      return res.status(400).json({
        success: false,
        error: 'User with this email already exists.'
      });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const otpDemo = Math.floor(100000 + Math.random() * 900000).toString();
    const otpExpiresAt = new Date(Date.now() + 10 * 60 * 1000);

    const user = await User.create({
      email: email.toLowerCase(),
      passwordHash,
      isVerified: false,
      otp: otpDemo,
      otpExpiresAt
    });

    return res.status(201).json({
      success: true,
      message: 'User registered successfully. Please verify OTP.',
      data: {
        id: user._id,
        email: user.email,
        isVerified: user.isVerified,
        otpDemo
      }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * POST /api/auth/verify-otp - OTP Verification
 */
const verifyOtp = async (req, res, next) => {
  try {
    const { email, otp } = req.body;

    if (!email || !otp) {
      return res.status(400).json({
        success: false,
        error: 'Email and OTP are required.'
      });
    }

    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found.'
      });
    }

    if (user.otp !== otp) {
      return res.status(400).json({
        success: false,
        error: 'Invalid OTP code.'
      });
    }

    user.isVerified = true;
    user.otp = null;
    user.otpExpiresAt = null;
    await user.save();

    return res.status(200).json({
      success: true,
      message: 'Email verified successfully.',
      data: {
        id: user._id,
        email: user.email,
        isVerified: user.isVerified
      }
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  register,
  login,
  verifyOtp,
  adminLogin,
  protectedHandler
};