const Article = require('../models/Article');
const { getCache, setCache } = require('../services/redisService');

/**
 * Public News Controller
 * ALL routes are unauthenticated. Server-side published: true filter is strictly enforced.
 */

// GET /api/feed/:country - Cached country feed
const getFeedByCountry = async (req, res, next) => {
  try {
    const country = req.params.country;
    const cacheKey = `feed:${country.toLowerCase()}`;

    const cachedData = await getCache(cacheKey);
    if (cachedData) {
      return res.status(200).json({
        success: true,
        source: 'cache',
        count: cachedData.length,
        data: cachedData
      });
    }

    // Always enforce published: true server-side
    const articles = await Article.find({
      published: true,
      country: { $regex: new RegExp(`^${country}$`, 'i') }
    })
      .sort({ publishedAt: -1, createdAt: -1 })
      .limit(30)
      .populate('createdBy', 'email role');

    await setCache(cacheKey, articles, 300); // 5 min cache

    return res.status(200).json({
      success: true,
      source: 'database',
      count: articles.length,
      data: articles
    });
  } catch (error) {
    next(error);
  }
};

// GET /api/news/trending - Trending articles
const getTrending = async (req, res, next) => {
  try {
    const cacheKey = 'news:trending';

    const cachedData = await getCache(cacheKey);
    if (cachedData) {
      return res.status(200).json({
        success: true,
        source: 'cache',
        count: cachedData.length,
        data: cachedData
      });
    }

    // Server-side published: true + isTrending: true (or top published sorted by date)
    const articles = await Article.find({
      published: true,
      isTrending: true
    })
      .sort({ publishedAt: -1, createdAt: -1 })
      .limit(20)
      .populate('createdBy', 'email role');

    await setCache(cacheKey, articles, 300);

    return res.status(200).json({
      success: true,
      source: 'database',
      count: articles.length,
      data: articles
    });
  } catch (error) {
    next(error);
  }
};

// GET /api/news/latest - Latest published articles
const getLatest = async (req, res, next) => {
  try {
    const cacheKey = 'news:latest';

    const cachedData = await getCache(cacheKey);
    if (cachedData) {
      return res.status(200).json({
        success: true,
        source: 'cache',
        count: cachedData.length,
        data: cachedData
      });
    }

    const articles = await Article.find({ published: true })
      .sort({ publishedAt: -1, createdAt: -1 })
      .limit(20)
      .populate('createdBy', 'email role');

    await setCache(cacheKey, articles, 180); // 3 min cache

    return res.status(200).json({
      success: true,
      source: 'database',
      count: articles.length,
      data: articles
    });
  } catch (error) {
    next(error);
  }
};

// GET /api/news/category/:category - Articles by category
const getByCategory = async (req, res, next) => {
  try {
    const { category } = req.params;
    const cacheKey = `news:category:${category.toLowerCase()}`;

    const cachedData = await getCache(cacheKey);
    if (cachedData) {
      return res.status(200).json({
        success: true,
        source: 'cache',
        count: cachedData.length,
        data: cachedData
      });
    }

    const query = { published: true };
    if (category.toLowerCase() !== 'all') {
      query.category = { $regex: new RegExp(`^${category}$`, 'i') };
    }

    const articles = await Article.find(query)
      .sort({ publishedAt: -1, createdAt: -1 })
      .limit(30)
      .populate('createdBy', 'email role');

    await setCache(cacheKey, articles, 300);

    return res.status(200).json({
      success: true,
      source: 'database',
      count: articles.length,
      data: articles
    });
  } catch (error) {
    next(error);
  }
};

// GET /api/news/search?q={query} - Full-text search
const searchNews = async (req, res, next) => {
  try {
    const searchQuery = req.query.q || req.query.query;

    if (!searchQuery || searchQuery.trim().length === 0) {
      return res.status(400).json({
        success: false,
        error: 'Search query parameter "q" is required.'
      });
    }

    // Text search query with published: true filter enforced
    let articles = await Article.find({
      published: true,
      $text: { $search: searchQuery.trim() }
    }, { score: { $meta: 'textScore' } })
      .sort({ score: { $meta: 'textScore' }, publishedAt: -1 })
      .limit(30)
      .populate('createdBy', 'email role');

    // Fallback regex search if text index yields zero results
    if (articles.length === 0) {
      const regex = new RegExp(searchQuery.trim(), 'i');
      articles = await Article.find({
        published: true,
        $or: [{ title: regex }, { shortDescription: regex }, { body: regex }]
      })
        .sort({ publishedAt: -1 })
        .limit(30)
        .populate('createdBy', 'email role');
    }

    return res.status(200).json({
      success: true,
      query: searchQuery.trim(),
      count: articles.length,
      data: articles
    });
  } catch (error) {
    next(error);
  }
};

// GET /api/article/:id - Single article detail
const getArticleById = async (req, res, next) => {
  try {
    const { id } = req.params;

    // Hardcoded server-side published filter
    const article = await Article.findOne({
      _id: id,
      published: true
    }).populate('createdBy', 'email role');

    if (!article) {
      return res.status(404).json({
        success: false,
        error: 'Article not found or is currently unpublished.'
      });
    }

    return res.status(200).json({
      success: true,
      data: article
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getFeedByCountry,
  getTrending,
  getLatest,
  getByCategory,
  searchNews,
  getArticleById
};
