const User = require('../models/User');
const Article = require('../models/Article');

/**
 * Bookmark Controller for authenticated public users
 */

// POST /api/bookmarks/:id - Save article to user bookmarks
const addBookmark = async (req, res, next) => {
  try {
    const articleId = req.params.id;

    // Verify article exists and is published
    const article = await Article.findOne({ _id: articleId, published: true });
    if (!article) {
      return res.status(404).json({
        success: false,
        error: 'Article not found or is unpublished.'
      });
    }

    const userId = req.user.id || req.user._id;
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found.'
      });
    }

    const isAlreadyBookmarked = user.bookmarks.some(
      bId => bId.toString() === articleId
    );

    if (isAlreadyBookmarked) {
      return res.status(200).json({
        success: true,
        message: 'Article is already in your bookmarks.',
        bookmarksCount: user.bookmarks.length,
        bookmarks: user.bookmarks
      });
    }

    user.bookmarks.push(articleId);
    await user.save();

    return res.status(200).json({
      success: true,
      message: 'Article saved to bookmarks successfully.',
      bookmarksCount: user.bookmarks.length,
      bookmarks: user.bookmarks
    });
  } catch (error) {
    next(error);
  }
};

// DELETE /api/bookmarks/:id - Remove article from user bookmarks
const removeBookmark = async (req, res, next) => {
  try {
    const articleId = req.params.id;
    const userId = req.user.id || req.user._id;
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found.'
      });
    }

    const initialLength = user.bookmarks.length;
    user.bookmarks = user.bookmarks.filter(
      bId => bId.toString() !== articleId
    );

    if (user.bookmarks.length === initialLength) {
      return res.status(404).json({
        success: false,
        error: 'Article was not found in your bookmarks.'
      });
    }

    await user.save();

    return res.status(200).json({
      success: true,
      message: 'Article removed from bookmarks.',
      bookmarksCount: user.bookmarks.length,
      bookmarks: user.bookmarks
    });
  } catch (error) {
    next(error);
  }
};

// GET /api/bookmarks - Get all saved bookmarks for logged-in user
const getBookmarks = async (req, res, next) => {
  try {
    const userId = req.user.id || req.user._id;
    const user = await User.findById(userId).populate({
      path: 'bookmarks',
      match: { published: true }
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found.'
      });
    }

    return res.status(200).json({
      success: true,
      count: user.bookmarks.length,
      data: user.bookmarks
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  addBookmark,
  removeBookmark,
  getBookmarks
};
