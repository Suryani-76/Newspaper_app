const Redis = require('ioredis');
const env = require('./env');

let redisClient = null;
let isRedisConnected = false;

const getRedisClient = () => {
  if (!redisClient) {
    try {
      redisClient = new Redis(env.redisUri, {
        maxRetriesPerRequest: 1,
        enableOfflineQueue: false,
        retryStrategy(times) {
          if (times > 3) {
            console.warn('[Redis] Max retries reached. Operating in bypass/fallback mode.');
            return null; // Stop retrying
          }
          return Math.min(times * 100, 2000);
        }
      });

      redisClient.on('connect', () => {
        isRedisConnected = true;
        console.log('[Redis] Connected successfully.');
      });

      redisClient.on('error', (err) => {
        isRedisConnected = false;
        console.warn(`[Redis Warning] ${err.message}`);
      });
    } catch (err) {
      console.warn(`[Redis Initialization Error] ${err.message}`);
      redisClient = null;
      isRedisConnected = false;
    }
  }
  return redisClient;
};

const isConnected = () => isRedisConnected;

module.exports = {
  getRedisClient,
  isConnected
};
