const dotenv = require('dotenv');
const path = require('path');

dotenv.config({ path: path.join(__dirname, '../../.env') });

module.exports = {
  port: process.env.PORT || 5000,
  nodeEnv: process.env.NODE_ENV || 'development',
  clientOrigin: process.env.CLIENT_ORIGIN || '*',
  mongoUri: process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/cinewire',
  redisUri: process.env.REDIS_URI || 'redis://127.0.0.1:6379',
  jwtSecret: process.env.JWT_SECRET || 'cinewire_jwt_secret_key_2026',
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '24h',
  s3Bucket: process.env.S3_BUCKET || 'cinewire-media',
  s3AccessKey: process.env.S3_ACCESS_KEY || '',
  s3SecretKey: process.env.S3_SECRET_KEY || '',
  s3Endpoint: process.env.S3_ENDPOINT || '',
  cdnBaseUrl: process.env.CDN_BASE_URL || 'https://cdn.cinewire.com',
  firebaseServiceAccount: process.env.FIREBASE_SERVICE_ACCOUNT || '{}',
  aiApiKey: process.env.AI_API_KEY || 'cw_ai_pay_per_use_key_9988776655'
};
