const express = require('express');
const router = express.Router();
const newsController = require('../controllers/newsController');

// Public Read Routes (No Auth Middleware - Server-Side Published Filter Enforced)

// GET /api/feed/:country - Cached country feed
router.get('/feed/:country', newsController.getFeedByCountry);

// GET /api/news/trending - Trending articles
router.get('/news/trending', newsController.getTrending);

// GET /api/news/latest - Latest articles
router.get('/news/latest', newsController.getLatest);

// GET /api/news/category/:category - Articles by category
router.get('/news/category/:category', newsController.getByCategory);

// GET /api/news/search?q={query} - Full-text search
router.get('/news/search', newsController.searchNews);

// GET /api/article/:id - Article detail
router.get('/article/:id', newsController.getArticleById);

module.exports = router;
