const express = require('express');
const { body } = require('express-validator');
const router = express.Router();
const adminController = require('../controllers/adminController');
const { requireAdmin } = require('../middleware/auth');
const validate = require('../middleware/validate');
const { CATEGORIES } = require('../models/Article');

// All Admin CMS routes require requireAdmin middleware with role checks

// POST /api/article - Create article
router.post(
  '/article',
  requireAdmin(['admin', 'marketer']),
  validate([
    body('title').trim().notEmpty().withMessage('Article title is required'),
    body('shortDescription').trim().notEmpty().withMessage('Short description is required'),
    body('body').notEmpty().withMessage('Article body content is required'),
    body('category').isIn(CATEGORIES).withMessage(`Category must be one of: ${CATEGORIES.join(', ')}`),
    body('country').trim().notEmpty().withMessage('Country parameter is required')
  ]),
  adminController.createArticle
);

// PUT /api/article/:id - Update article
router.put(
  '/article/:id',
  requireAdmin(['admin', 'marketer']),
  adminController.updateArticle
);

// POST /api/article/:id/publish - Publish/Unpublish toggle
router.post(
  '/article/:id/publish',
  requireAdmin(['admin', 'marketer']),
  adminController.togglePublish
);

// POST /api/ai/assist - Trigger AI assist (summarise, tag, translate, duplicate-check)
router.post(
  '/ai/assist',
  requireAdmin(['admin', 'marketer']),
  validate([
    body('action').notEmpty().withMessage('AI action parameter is required'),
    body('text').notEmpty().withMessage('Text content is required for AI processing')
  ]),
  adminController.aiAssist
);

module.exports = router;
