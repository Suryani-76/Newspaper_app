const express = require('express');
const { body } = require('express-validator');
const router = express.Router();
const pushController = require('../controllers/pushController');
const validate = require('../middleware/validate');

// Push Notification Subscription (No Auth Required)

// POST /api/push/subscribe
router.post(
  '/push/subscribe',
  validate([
    body('token').trim().notEmpty().withMessage('FCM device token is required'),
    body('country').trim().notEmpty().withMessage('Country is required')
  ]),
  pushController.subscribe
);

module.exports = router;
