const express = require('express');
const router = express.Router();
const bookmarkController = require('../controllers/bookmarkController');
const { requireAuth } = require('../middleware/auth');

// All bookmark routes require valid Public User JWT Authentication

// POST /api/bookmarks/:id - Save article
router.post('/bookmarks/:id', requireAuth, bookmarkController.addBookmark);

// DELETE /api/bookmarks/:id - Remove saved article
router.delete('/bookmarks/:id', requireAuth, bookmarkController.removeBookmark);

// GET /api/bookmarks - Get saved bookmarks for logged-in user
router.get('/bookmarks', requireAuth, bookmarkController.getBookmarks);

module.exports = router;
