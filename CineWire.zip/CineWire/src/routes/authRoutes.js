const express = require('express');
const { body } = require('express-validator');
const router = express.Router();
const authController = require('../controllers/authController');
const authMiddleware = require('../middleware/auth');
const validate = require('../middleware/validate');
const { authLimiter } = require('../middleware/rateLimiter');

// Public User Auth Routes (Tuned Rate Limiting Applied)

// POST /api/auth/register
router.post(
  '/auth/register',
  authLimiter,
  validate([
    body('email').isEmail().withMessage('Please provide a valid email address'),
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters long')
  ]),
  authController.register
);

// POST /api/auth/login (Public User & Admin Dispatcher)
router.post(
  '/auth/login',
  authLimiter,
  validate([
    body('email').isEmail().withMessage('Please provide a valid email address'),
    body('password').notEmpty().withMessage('Password is required')
  ]),
  authController.login
);

// POST /api/auth/protected - Demonstrates stacking authenticateToken and requireRole('admin')
router.post(
  '/auth/protected',
  authMiddleware.authenticateToken,
  authMiddleware.requireRole('admin'),
  authController.protectedHandler
);

// POST /api/auth/verify-otp
router.post(
  '/auth/verify-otp',
  authLimiter,
  validate([
    body('email').isEmail().withMessage('Please provide a valid email address'),
    body('otp').isLength({ min: 6, max: 6 }).withMessage('OTP must be a 6-digit code')
  ]),
  authController.verifyOtp
);

// POST /api/admin/auth/login (Dedicated Admin CMS Login Endpoint)
router.post(
  '/admin/auth/login',
  authLimiter,
  validate([
    body('email').isEmail().withMessage('Please provide a valid admin email address'),
    body('password').notEmpty().withMessage('Password is required')
  ]),
  authController.adminLogin
);

module.exports = router;