const mongoose = require('mongoose');

const adminSchema = new mongoose.Schema(
  {
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
      index: true
    },
    passwordHash: {
      type: String,
      required: true
    },
    role: {
      type: String,
      enum: ['admin', 'marketer'],
      default: 'admin'
    }
  },
  {
    timestamps: true
  }
);

adminSchema.methods.toJSON = function () {
  const admin = this.toObject();
  delete admin.passwordHash;
  return admin;
};

module.exports = mongoose.model('Admin', adminSchema);
