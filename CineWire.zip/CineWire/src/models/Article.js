const mongoose = require('mongoose');

const CATEGORIES = [
  'Horror',
  'Sci-Fi',
  'Thriller',
  'Action',
  'Comedy',
  'Drama',
  'Romance',
  'Fantasy',
  'Mystery',
  'Animation'
];

const LANGUAGES_COUNTRIES = ['English', 'Telugu', 'Hindi', 'Tamil', 'Kannada', 'USA', 'India', 'UK', 'Global'];

const articleSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
      trim: true
    },
    slug: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
      index: true
    },
    shortDescription: {
      type: String,
      required: true,
      trim: true
    },
    body: {
      type: String,
      required: true
    },
    category: {
      type: String,
      required: true,
      enum: CATEGORIES,
      index: true
    },
    country: {
      type: String,
      required: true,
      trim: true,
      index: true
    },
    language: {
      type: String,
      default: 'English',
      trim: true
    },
    imageUrl: {
      type: String,
      default: ''
    },
    sourceName: {
      type: String,
      default: 'CineWire Desk'
    },
    publishedAt: {
      type: Date,
      default: null,
      index: true
    },
    published: {
      type: Boolean,
      default: false,
      index: true
    },
    isTrending: {
      type: Boolean,
      default: false,
      index: true
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Admin'
    }
  },
  {
    timestamps: true
  }
);

// Full-text search index on title, shortDescription, and body
articleSchema.index(
  {
    title: 'text',
    shortDescription: 'text',
    body: 'text'
  },
  {
    weights: {
      title: 10,
      shortDescription: 5,
      body: 1
    },
    name: 'ArticleTextIndex'
  }
);

// Compound index for feed queries
articleSchema.index({ published: 1, country: 1, publishedAt: -1 });
articleSchema.index({ published: 1, category: 1, publishedAt: -1 });
articleSchema.index({ published: 1, isTrending: 1, publishedAt: -1 });

module.exports = mongoose.model('Article', articleSchema);
module.exports.CATEGORIES = CATEGORIES;
module.exports.LANGUAGES_COUNTRIES = LANGUAGES_COUNTRIES;
