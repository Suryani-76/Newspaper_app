const app = require('./app');
const env = require('./config/env');
const connectDB = require('./config/db');
const { getRedisClient } = require('./config/redis');

const startServer = async () => {
  // 1. Connect MongoDB
  await connectDB();

  // 2. Initialize Redis client (logs status, won't crash if offline)
  getRedisClient();

  // 3. Start Express server
  const server = app.listen(env.port, () => {
    console.log(`====================================================`);
    console.log(`  🎬 CineWire Backend API Service is running`);
    console.log(`  🌐 Environment: ${env.nodeEnv}`);
    console.log(`  🚀 Server URL:  http://localhost:${env.port}`);
    console.log(`====================================================`);
  });

  // Handle unhandled promise rejections gracefully
  process.on('unhandledRejection', (err) => {
    console.error(`[Unhandled Rejection Error] ${err.message}`);
  });
};

startServer();
