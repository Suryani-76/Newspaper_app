const jwt = require('jsonwebtoken');
const env = require('../config/env');

/**
 * Token Connection Extraction & Validation Middleware
 * Validates Bearer token from Authorization header and attaches decoded user data to req.user
 */
const authenticateToken = (req, res, next) => {
  try {
    if (!req.headers.authorization) {
      return res.status(401).json({
        success: false,
        message: 'Missing Authorization Header'
      });
    }

    if (!req.headers.authorization.startsWith('Bearer')) {
      return res.status(401).json({
        success: false,
        message: 'Invalid Authorization Header Format'
      });
    }

    const token = req.headers.authorization.split(' ')[1];

    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'Missing Authorization Header'
      });
    }

    const decoded = jwt.verify(token, env.jwtSecret);

    req.user = {
      id: decoded.id,
      email: decoded.email,
      role: decoded.role
    };

    next();
  } catch (error) {
    return res.status(403).json({
      success: false,
      message: 'Invalid or Expired Token'
    });
  }
};

/**
 * Permission Guard Middleware
 * Checks req.user.role against the required targetRole
 */
const requireRole = (targetRole) => {
  return (req, res, next) => {
    if (!req.user || req.user.role !== targetRole) {
      return res.status(403).json({
        success: false,
        message: 'Access Denied: Insufficient Role Permissions'
      });
    }

    next();
  };
};

/**
 * Require authentication middleware (alias for authenticateToken)
 */
const requireAuth = authenticateToken;

/**
 * Require admin role middleware generator
 */
const requireAdmin = (allowedRoles = ['admin']) => {
  const rolesArray = Array.isArray(allowedRoles) ? allowedRoles : [allowedRoles];
  return (req, res, next) => {
    authenticateToken(req, res, () => {
      if (!req.user || !rolesArray.includes(req.user.role)) {
        return res.status(403).json({
          success: false,
          message: 'Access Denied: Insufficient Role Permissions'
        });
      }
      next();
    });
  };
};

module.exports = {
  authenticateToken,
  requireRole,
  requireAuth,
  requireAdmin
};