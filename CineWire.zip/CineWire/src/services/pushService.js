const DeviceToken = require('../models/DeviceToken');

/**
 * Push Notification Service (Firebase FCM Stub)
 */
class PushService {
  async registerToken({ token, country }) {
    if (!token || !country) {
      throw new Error('Device token and country are required');
    }

    const deviceToken = await DeviceToken.findOneAndUpdate(
      { token: token.trim() },
      { country: country.trim() },
      { upsert: true, new: true, runValidators: true }
    );

    return deviceToken;
  }

  async sendBreakingNewsNotification(country, article) {
    const tokens = await DeviceToken.find({ country }).select('token');
    console.log(`[FCM Push] Sending breaking news notification to ${tokens.length} devices in ${country} for article: "${article.title}"`);
    return {
      successCount: tokens.length,
      failureCount: 0
    };
  }
}

module.exports = new PushService();
