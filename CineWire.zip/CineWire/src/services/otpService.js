/**
 * OTP Service for user account activation
 */
const generateOTP = () => {
  // Generate secure random 6-digit OTP
  const otp = Math.floor(100000 + Math.random() * 900000).toString();
  // OTP valid for 10 minutes
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000);
  return { otp, expiresAt };
};

const verifyOTP = (user, inputOtp) => {
  if (!user.otp || !user.otpExpiresAt) {
    return { valid: false, message: 'No OTP requested or account already verified.' };
  }

  if (new Date() > new Date(user.otpExpiresAt)) {
    return { valid: false, message: 'OTP has expired. Please request a new one.' };
  }

  if (user.otp !== inputOtp.trim()) {
    return { valid: false, message: 'Invalid OTP code.' };
  }

  return { valid: true };
};

module.exports = {
  generateOTP,
  verifyOTP
};
