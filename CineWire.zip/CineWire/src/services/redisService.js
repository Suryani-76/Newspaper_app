const { getRedisClient, isConnected } = require('../config/redis');

const DEFAULT_TTL = 300; // 5 minutes in seconds

const getCache = async (key) => {
  if (!isConnected()) return null;
  try {
    const client = getRedisClient();
    if (!client) return null;
    const data = await client.get(key);
    return data ? JSON.parse(data) : null;
  } catch (err) {
    console.warn(`[Redis GetCache Error] ${err.message}`);
    return null;
  }
};

const setCache = async (key, value, ttlInSeconds = DEFAULT_TTL) => {
  if (!isConnected()) return false;
  try {
    const client = getRedisClient();
    if (!client) return false;
    await client.set(key, JSON.stringify(value), 'EX', ttlInSeconds);
    return true;
  } catch (err) {
    console.warn(`[Redis SetCache Error] ${err.message}`);
    return false;
  }
};

const deleteCache = async (patternOrKey) => {
  if (!isConnected()) return false;
  try {
    const client = getRedisClient();
    if (!client) return false;
    
    if (patternOrKey.includes('*')) {
      const keys = await client.keys(patternOrKey);
      if (keys.length > 0) {
        await client.del(...keys);
      }
    } else {
      await client.del(patternOrKey);
    }
    return true;
  } catch (err) {
    console.warn(`[Redis DeleteCache Error] ${err.message}`);
    return false;
  }
};

const clearFeedCaches = async (country = null, category = null) => {
  console.log(`[Redis Cache] Invalidating feed caches... (Country: ${country}, Category: ${category})`);
  await deleteCache('feed:*');
  await deleteCache('news:trending');
  await deleteCache('news:latest');
  await deleteCache('news:category:*');
};

module.exports = {
  getCache,
  setCache,
  deleteCache,
  clearFeedCaches
};
