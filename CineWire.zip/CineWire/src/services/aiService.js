const env = require('../config/env');

/**
 * AI Integration Client (Pay-per-use API Client Stub)
 * Handles article summarisation, auto-tagging, language translation, and duplicate detection.
 */
class AIService {
  constructor() {
    this.apiKey = env.aiApiKey;
  }

  async assist({ action, text, targetLanguage, existingTitles = [] }) {
    if (!text || typeof text !== 'string') {
      throw new Error('Valid text content is required for AI assistance');
    }

    // Simulate pay-per-use API response delay and processing logic
    switch (action) {
      case 'summarise':
      case 'summarize':
        return {
          action: 'summarise',
          summary: this._generateSummary(text),
          wordCountOriginal: text.split(' ').length,
          wordCountSummary: 25,
          tokensUsed: 120
        };

      case 'tag':
        return {
          action: 'tag',
          tags: this._generateTags(text),
          suggestedCategory: this._suggestCategory(text),
          tokensUsed: 85
        };

      case 'translate':
        return {
          action: 'translate',
          targetLanguage: targetLanguage || 'English',
          translatedText: `[Translated to ${targetLanguage || 'English'}]: ${text.substring(0, 300)}...`,
          tokensUsed: 210
        };

      case 'duplicateCheck':
      case 'duplicate-check':
        return this._checkDuplicate(text, existingTitles);

      default:
        throw new Error(`Unsupported AI action: '${action}'. Allowed: summarise, tag, translate, duplicate-check`);
    }
  }

  _generateSummary(text) {
    const sentences = text.split('.').filter(s => s.trim().length > 0);
    if (sentences.length <= 2) return text;
    return `${sentences[0].trim()}. ${sentences[1].trim()}.`;
  }

  _generateTags(text) {
    const keywords = ['Hollywood', 'BoxOffice', 'Premiere', 'Trailer', 'Casting', 'Director', 'Streaming', 'Festival'];
    const lower = text.toLowerCase();
    const matched = keywords.filter(k => lower.includes(k.toLowerCase()));
    return matched.length > 0 ? matched : ['FilmNews', 'CinemaUpdate', 'Exclusive'];
  }

  _suggestCategory(text) {
    const lower = text.toLowerCase();
    if (lower.includes('scary') || lower.includes('ghost') || lower.includes('haunted')) return 'Horror';
    if (lower.includes('alien') || lower.includes('space') || lower.includes('future')) return 'Sci-Fi';
    if (lower.includes('funny') || lower.includes('laugh') || lower.includes('comedy')) return 'Comedy';
    if (lower.includes('fight') || lower.includes('stunt') || lower.includes('explosion')) return 'Action';
    return 'Drama';
  }

  _checkDuplicate(titleOrText, existingTitles = []) {
    const lowerInput = titleOrText.toLowerCase();
    const duplicate = existingTitles.find(title => {
      const lowerExisting = title.toLowerCase();
      return lowerExisting === lowerInput || (lowerInput.length > 10 && lowerExisting.includes(lowerInput));
    });

    return {
      action: 'duplicateCheck',
      isPossibleDuplicate: !!duplicate,
      matchedTitle: duplicate || null,
      similarityScore: duplicate ? 0.95 : 0.05,
      tokensUsed: 40
    };
  }
}

module.exports = new AIService();
